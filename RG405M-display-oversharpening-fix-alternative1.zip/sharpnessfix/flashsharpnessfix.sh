# Script to disable oversharpening display on Anbernic RG405M - firmware v1.15

echo "Copying newer xxd binary to temp location"
mkdir -p /data/xxdtmp
cp xxd /data/xxdtmp/xxd
chmod +x /data/xxdtmp/xxd

echo "Dumping /system_ext/etc/build.prop directly from super partition"
xxd -l 0x8A5 -s 0x74EE7690 /dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/super -p | xxd -r -p > build.prop.dumped

# Compare md5sum of the dumped build.prop and what it should actually be to make sure that we're reading from super partition correctly.
originalmd5="feea5b4c6316371a7e415fa0c5096ef1  -"
dumpedmd5=$(cat build.prop.dumped | md5sum)

if [ "$originalmd5" != "$dumpedmd5" ] 
then
    echo "Original build.prop and dumped build.prop md5sum are not equal!  Aborting..."
	exit 1
else
    echo "Original build.prop and dumped build.prop md5sum matching. Continuing..."
fi

# Ensure that no-one has messed the build.prop.fixed file, mismatching file size will cause a boot failure. 
buildpropsize="2213"
buildpropsizeondisk=$(wc -c < build.prop.fixed)

if [ "$buildpropsize" != "$buildpropsizeondisk" ] 
then
    echo "build.prop.fixed file length is not the correct size!  Aborting..."
	exit 1
else
    echo "build.prop.fixed file length is the correct size. Continuing..."
fi

fixedmd5="7173ad6c36e7c940709f3e99eb03c54e  -"
fixedmd5ondisk=$(cat build.prop.fixed | md5sum)

if [ "$fixedmd5" != "$fixedmd5ondisk" ] 
then
    echo "build.prop.fixed has wrong md5sum! It has been tampered with!  Aborting..."
	exit 1
else
    echo "build.prop.fixed has correct md5sum. Begin flashing..."
fi

buildpropfixedhex=$(xxd -o 0x74EE7690 build.prop.fixed)                                               
printf "$buildpropfixedhex" | /data/xxdtmp/xxd -r - /dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/super

echo "Exit code is: $?"

echo "Flashing complete! Please reboot your RG405M to apply changes."