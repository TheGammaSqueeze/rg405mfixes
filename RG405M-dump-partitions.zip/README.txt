---------------------------------------------------------------------
Anbernic RG405M Partition Dumping Script
---------------------------------------------------------------------

----------------------------
Author
----------------------------
TheGammaSqueeze


----------------------------
Information
----------------------------

This will dump the following partitions:
boot
vbmeta
vendor_boot
super

----------------------------
Instructions (via Termux app)
----------------------------

This must be executed on the RG405M itself and not via ADB.
This process requires some manual typing on the RG405M using the Termux app.

Prerequisites: 
Termux app installed on your RG405M: https://termux.dev/en/ OR https://play.google.com/store/apps/details?id=com.termux
Copy the "dumpsuper" folder to the root of your internal storage (*NOT YOUR SD CARD*) on the RG405M 

Flashing steps:
- Open the termux app, type in the command "su" (without quotes) and press enter
- Type in the following command and press enter: cd /sdcard/dumpsuper
- Type in the following command and press enter: sh dump.sh
- Wait until the process is complete, you will see the following message once done: "Dump complete.". You can close Termux now.
- That's it. Please back up your files to your computer, they are stored in the internal storage under the dumpsuper folder.