# Script to dump the super partition

mkdir -p /sdcard/dumpsuper

echo "Begin dumping vbmeta"
dd "if=/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/vbmeta_a" "of=/sdcard/dumpsuper/vbmeta_stock.img"

echo "Begin dumping boot"
dd "if=/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/boot_a" "of=/sdcard/dumpsuper/boot_stock.img"

echo "Begin dumping vendor_boot"
dd "if=/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/vendor_boot_a" "of=/sdcard/dumpsuper/vendor_boot_stock.img"

echo "Begin dumping super (this will take a while)"
dd "if=/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/super" "of=/sdcard/dumpsuper/super_stock.img"
echo "Dump complete."
