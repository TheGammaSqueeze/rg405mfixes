---------------------------------------------------------------------
Anbernic RG405M Display Oversharpening Fix
---------------------------------------------------------------------

----------------------------
Author
----------------------------
TheGammaSqueeze


----------------------------
Information
----------------------------

This will remove the oversharpening effect exhibited in the RG405M screens from factory.

This patches the system_ext image in the super partition without having to do a full reflash. Specifically, it will overwrite some bytes by directly modifying the partition on the eMMC.
The offending file is in /system_ext/etc/build.prop.

This will work on both locked and unlocked bootloaders, flashed via the Termux app. There is no risk here for this specific fix causing issues with boot loops as the super partition is not a signed partition.

----------------------------
Instructions (For flashing via Termux app)
----------------------------

This must be executed on the RG405M itself and not via ADB.
This process requires some manual typing on the RG405M using the Termux app.

Prerequisites: 
Termux app installed on your RG405M: https://termux.dev/en/ OR https://play.google.com/store/apps/details?id=com.termux
Copy the "sharpnessfix" folder to the root of your internal storage (*NOT YOUR SD CARD*) on the RG405M 

Flashing steps:
- Open the termux app, type in the command "su" (without quotes) and press enter
- Type in the following command and press enter: cd /sdcard/sharpnessfix
- Type in the following command and press enter: sh flashsharpnessfix.sh
- Wait until the process is complete, you will see the following message once done: "Flashing complete! Please reboot your RG405M to apply changes.". Reboot your device when you see this.
- That's it. The screen sharpening will be removed.
