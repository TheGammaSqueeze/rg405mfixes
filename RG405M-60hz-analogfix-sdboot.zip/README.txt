---------------------------------------------------------------------
Anbernic RG405M 60hz display timing and analog stick calibration fix
---------------------------------------------------------------------

----------------------------
Author
----------------------------
TheGammaSqueeze


----------------------------
WARNING:
----------------------------
DO NOT USE THIS IN CONJUNCTION WITH ANY OTHER TOOLS WHICH MODIFIES YOUR PARTITIONS.
FAILURE TO FOLLOW THIS WILL RESULT IN YOUR DEVICE BOOT LOOPING, YOU WILL NEED TO USE THE BLACK-SERAPH RG405M UNBRICKER TOOL (https://www.patreon.com/posts/anbernic-rg405m-81427437)

I have bundled in Black-Seraphs SDCard Boot Enabler so this shouldn't be an issue for most.


----------------------------
Information
----------------------------
This provides an updated vbmeta image to allow custom signed DTBO and vendor_boot images to be flashed.

The DTBO image contains the new display timing which will give you a refresh rate of 59.997hz after you turn the screen off and on again. 
It also fixes the calibration of the analog sticks to allow more precise control.

The vendor_boot image is taken from Black Seraph's SD card loader (https://www.patreon.com/posts/anbernic-rg405m-81481065) so that you don't need to flash this separately. 


----------------------------
Instructions (For unlocked bootloader, flashing via Fastbootd)
----------------------------

If you have not already unlocked your bootloader, following this process will factory reset your device. 
If you wish to avoid this, please read the instructions for locked bootloaders below.

Prerequisites:
ADB and Fastboot tools + drivers, ensure you install the Universal ADB Driver: https://github.com/K3V1991/ADB-and-FastbootPlusPlus
Enable USB Debugging on the RG405M: https://developer.android.com/studio/debug/dev-options

Unlocking bootloader (Skip if already done, will factory reset your RG405M):
- Connect your RG405M to your PC while booted into Android, open a command prompt window, and issue the following command: adb reboot bootloader
- Your RG405M will reboot, and you will see the text "fastboot mode" on the screen next to the Anbernic logo.
- Open this site in Google Chrome: https://turtleletortue.github.io/subut-rehost/
- Click Connect.
- Click "fastboot gadget" and connect.
- Click Unlock.
- On the device there will be a warning "Warning: Unlock device may erase user data. Press volume down button to confirm that. Press volume up button to cancel."
- Press the Home / Back button on the RG405M to proceed.
- Wait for it to complete.
- Then reboot by pressing and holding the Power and Vol down buttons.


Flashing Steps:
- Make sure that your RG405M is booted into Android, with USB Debugging enabled, and the USB is connected to your PC.
- In the extracted folder, you will see a fastboot_flash.bat script. Open this script, ensuring that the "flash" folder is also in the same location as the script.
- That's it, the script will flash all the relevant images then reboot your device. The screen refresh rate change don't take effect upon any reboots until you turn the screen off and on again.


----------------------------
Instructions (For locked bootloader, flashing via Termux app)
----------------------------

If your bootloader is locked, then you can follow these instructions instead. This must be executed on the RG405M itself and not via ADB.
This process requires some manual typing on the RG405M, but you won't have to unlock your bootloader and go through a factory reset.

Prerequisites: 
Termux app installed on your RG405M: https://termux.dev/en/ OR https://play.google.com/store/apps/details?id=com.termux
Copy the "flash" folder to the root of your internal storage (*NOT YOUR SD CARD*) on the RG405M 

Flashing steps:
- Open the termux app, type in the command "su" (without quotes) and press enter
- Type in the following command and press enter: cd /sdcard/flash
- Type in the following command and press enter: sh flashtermux.sh
- Wait until the process is complete, you will see the following message once done: "Flashing complete, please reboot your device". Reboot your device when you see this.
- That's it. The screen refresh rate change doesn't take effect upon any reboots until you turn the screen off and on again.
