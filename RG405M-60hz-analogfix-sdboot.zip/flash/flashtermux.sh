dd "if=/sdcard/flash/vbmeta_custom.img" "of=/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/vbmeta_a"
dd "if=/sdcard/flash/vbmeta_custom.img" "of=/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/vbmeta_b"
dd "if=/sdcard/flash/dtbo_custom.img" "of=/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/dtbo_a"
dd "if=/sdcard/flash/dtbo_custom.img" "of=/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/dtbo_b"
dd "if=/sdcard/flash/vendor_boot_custom.img" "of=/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/vendor_boot_a"
dd "if=/sdcard/flash/vendor_boot_custom.img" "of=/dev/block/platform/soc/soc:ap-apb/71400000.sdio/by-name/vendor_boot_b"

echo "Flashing complete, please reboot your device"